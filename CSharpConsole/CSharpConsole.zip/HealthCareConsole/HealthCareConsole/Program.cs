﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HealthCareConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Azure ML alert: this employee need to take care.");
            //Console.WriteLine("Azure ML alert: this employee need to take care.");
            Console.ReadLine();
        }
    }
}
